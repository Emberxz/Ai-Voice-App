# VoiceScribe AI Companion 🎙️🤖

A powerful, production-ready voice assistant that transcribes your speech in real-time and acts as your AI companion. Built with Python, Google Speech-to-Text, and a modern Qt interface.

## ✨ Features
- Real-time voice transcription (Google Speech-to-Text)
- AI Companion mode (OpenAI/Anthropic)
- SQLite auto-save and full-text search
- Export to TXT, Markdown, JSON
- Modern dark UI
- Keyboard shortcuts
- Multi-personality AI
- Offline/mock mode if no API key

## 🚀 Quick Start

### Prerequisites
- Python 3.8+
- Google Cloud account (Speech-to-Text API enabled)
- OpenAI API key (for AI companion features)
- Microphone

### Installation

1. Clone the repo
```bash
git clone https://github.com/yourusername/voicescribe-ai-companion.git
cd voicescribe-ai-companion
```
2. Install dependencies
```bash
pip install -r requirements.txt
```
3. Set up credentials
   - Google: download service account key as `credentials/google-credentials.json`
   - OpenAI: set `OPENAI_API_KEY` in `.env`

4. Run the app
```bash
python main.py
```

## 📂 Project Structure

```
voicescribe-ai-companion/
├── main.py
├── app/
│   ├── audio_capture.py
│   ├── transcriber.py
│   ├── ai_companion.py
│   ├── database.py
│   └── ui/
│       ├── main_window.py
│       └── styles.qss
├── config/
│   └── personalities.json
├── credentials/
│   └── google-credentials.json
├── data/
│   └── voicescribe.db
├── exports/
├── requirements.txt
├── .env.example
├── README.md
```

## 🎯 Usage

- Space: Start/Stop recording
- Ctrl+C: Copy transcript
- Ctrl+S: Save transcript
- Ctrl+F: Search
- Esc: Clear current

## 🔧 Personalities

Edit `config/personalities.json` for custom AI behavior.

## 🐛 Troubleshooting

- Check microphone with `python -m sounddevice`
- Ensure API keys are valid
- Lower VAD aggressiveness for better performance

## 📜 License

MIT

---

**Made with ❤️ by [Your Name]**