import os
from datetime import datetime
from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QTextEdit,
    QTabWidget, QCheckBox, QLineEdit, QListWidget, QFormLayout, QComboBox, QSlider,
    QStatusBar, QShortcut, QApplication
)
from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QKeySequence, QTextCursor
from app.audio_capture import AudioCapture
from app.transcriber import Transcriber
from app.ai_companion import AICompanion
from app.database import TranscriptDatabase

EXPORT_DIR = os.path.join(os.path.dirname(__file__), "../../exports")
DATA_DIR = os.path.join(os.path.dirname(__file__), "../../data")

class VoiceScribeWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.database = TranscriptDatabase()
        self.audio_capture = AudioCapture()
        self.transcriber = Transcriber()
        self.ai_companion = AICompanion()
        self.session_id = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.is_recording = False
        self.ai_mode = False
        self.init_ui()
        self.setup_connections()
        self.setup_shortcuts()
        self.load_recent_transcripts()

    def init_ui(self):
        self.setWindowTitle("VoiceScribe AI Companion 🎙️")
        self.setGeometry(100, 100, 1200, 800)
        # Stylesheet
        qss_path = os.path.join(os.path.dirname(__file__), "styles.qss")
        if os.path.exists(qss_path):
            with open(qss_path, "r") as f:
                self.setStyleSheet(f.read())

        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)

        # Header
        header = QWidget()
        header_layout = QHBoxLayout(header)
        title_label = QLabel("🎙️ VoiceScribe AI Companion")
        title_label.setStyleSheet("font-size: 24px; font-weight: bold; color: #ffffff;")
        header_layout.addWidget(title_label)
        header_layout.addStretch()
        self.ai_mode_check = QCheckBox("AI Companion Mode")
        self.ai_mode_check.setStyleSheet("font-size: 16px;")
        self.ai_mode_check.toggled.connect(self.toggle_ai_mode)
        header_layout.addWidget(self.ai_mode_check)
        main_layout.addWidget(header)

        # Tabs
        self.tabs = QTabWidget()

        # Transcription Tab
        transcript_tab = QWidget()
        transcript_layout = QVBoxLayout(transcript_tab)
        control_panel = QWidget()
        control_layout = QHBoxLayout(control_panel)
        self.record_btn = QPushButton("🎤 Start Recording")
        self.record_btn.setObjectName("recordBtn")
        self.record_btn.clicked.connect(self.toggle_recording)
        control_layout.addWidget(self.record_btn)
        self.clear_btn = QPushButton("🗑️ Clear")
        self.clear_btn.clicked.connect(self.clear_current)
        control_layout.addWidget(self.clear_btn)
        self.copy_btn = QPushButton("📋 Copy")
        self.copy_btn.clicked.connect(self.copy_to_clipboard)
        control_layout.addWidget(self.copy_btn)
        self.save_btn = QPushButton("💾 Save")
        self.save_btn.clicked.connect(self.save_current)
        control_layout.addWidget(self.save_btn)
        control_layout.addStretch()
        self.status_label = QLabel("Ready")
        self.status_label.setStyleSheet("color: #14a085; font-weight: bold;")
        control_layout.addWidget(self.status_label)
        transcript_layout.addWidget(control_panel)
        transcript_layout.addWidget(QLabel("Current Session:"))
        self.current_text = QTextEdit()
        self.current_text.setPlaceholderText("Your transcription will appear here...")
        transcript_layout.addWidget(self.current_text)
        # AI Response Area
        self.ai_response_widget = QWidget()
        ai_layout = QVBoxLayout(self.ai_response_widget)
        ai_layout.addWidget(QLabel("AI Response:"))
        self.ai_response_text = QTextEdit()
        self.ai_response_text.setPlaceholderText("AI responses will appear here...")
        self.ai_response_text.setMaximumHeight(150)
        ai_layout.addWidget(self.ai_response_text)
        self.ai_response_widget.setVisible(False)
        transcript_layout.addWidget(self.ai_response_widget)
        self.tabs.addTab(transcript_tab, "📝 Transcription")

        # History Tab
        history_tab = QWidget()
        history_layout = QVBoxLayout(history_tab)
        search_widget = QWidget()
        search_layout = QHBoxLayout(search_widget)
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("🔍 Search transcripts...")
        self.search_input.returnPressed.connect(self.search_transcripts)
        search_layout.addWidget(self.search_input)
        self.search_btn = QPushButton("Search")
        self.search_btn.clicked.connect(self.search_transcripts)
        search_layout.addWidget(self.search_btn)
        history_layout.addWidget(search_widget)
        self.history_list = QListWidget()
        self.history_list.itemDoubleClicked.connect(self.load_transcript_detail)
        history_layout.addWidget(self.history_list)
        export_widget = QWidget()
        export_layout = QHBoxLayout(export_widget)
        self.export_txt_btn = QPushButton("📄 Export as TXT")
        self.export_txt_btn.clicked.connect(lambda: self.export_transcripts('txt'))
        export_layout.addWidget(self.export_txt_btn)
        self.export_md_btn = QPushButton("📝 Export as Markdown")
        self.export_md_btn.clicked.connect(lambda: self.export_transcripts('md'))
        export_layout.addWidget(self.export_md_btn)
        self.export_json_btn = QPushButton("📊 Export as JSON")
        self.export_json_btn.clicked.connect(lambda: self.export_transcripts('json'))
        export_layout.addWidget(self.export_json_btn)
        export_layout.addStretch()
        history_layout.addWidget(export_widget)
        self.tabs.addTab(history_tab, "📚 History")

        # Settings Tab
        settings_tab = QWidget()
        settings_layout = QVBoxLayout(settings_tab)
        settings_form = QFormLayout()
        self.device_combo = QComboBox()
        try:
            import sounddevice as sd
            devices = sd.query_devices()
            for i, device in enumerate(devices):
                if device['max_input_channels'] > 0:
                    self.device_combo.addItem(f"{device['name']}", i)
        except Exception:
            self.device_combo.addItem("Default", 0)
        settings_form.addRow("Microphone:", self.device_combo)
        self.vad_slider = QSlider(Qt.Horizontal)
        self.vad_slider.setRange(0, 3)
        self.vad_slider.setValue(2)
        self.vad_slider.setTickPosition(QSlider.TicksBelow)
        self.vad_slider.setTickInterval(1)
        settings_form.addRow("VAD Sensitivity:", self.vad_slider)
        settings_form.addRow(QLabel("<b>AI Companion Settings</b>"))
        self.personality_combo = QComboBox()
        self.personality_combo.addItems(["Friendly", "Professional", "Creative", "Analytical"])
        settings_form.addRow("Personality:", self.personality_combo)
        self.tts_check = QCheckBox("Enable Text-to-Speech")
        settings_form.addRow("Voice Feedback:", self.tts_check)
        settings_layout.addLayout(settings_form)
        settings_layout.addStretch()
        about_text = QLabel("""
        <h3>VoiceScribe AI Companion v1.0</h3>
        <p>A powerful voice transcription and AI companion application.</p>
        <p><b>Shortcuts:</b></p>
        <ul>
            <li>Space - Start/Stop Recording</li>
            <li>Ctrl+C - Copy Transcript</li>
            <li>Ctrl+S - Save Transcript</li>
            <li>Ctrl+F - Search</li>
            <li>Esc - Clear Current</li>
        </ul>
        <p><i>Built with ❤️ using Python and Qt</i></p>
        """)
        about_text.setWordWrap(True)
        settings_layout.addWidget(about_text)
        self.tabs.addTab(settings_tab, "⚙️ Settings")

        main_layout.addWidget(self.tabs)
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)
        self.status_bar.showMessage("Ready to transcribe")

    def setup_connections(self):
        self.audio_capture.audio_chunk.connect(self.process_audio)
        self.audio_capture.status_update.connect(self.update_status)
        self.transcriber.transcription_ready.connect(self.add_transcription)
        self.transcriber.error.connect(self.update_status)
        self.ai_companion.response_ready.connect(self.add_ai_response)
        self.ai_companion.error.connect(self.update_status)

    def setup_shortcuts(self):
        QShortcut(QKeySequence("Space"), self, self.toggle_recording)
        QShortcut(QKeySequence("Ctrl+C"), self, self.copy_to_clipboard)
        QShortcut(QKeySequence("Ctrl+S"), self, self.save_current)
        QShortcut(QKeySequence("Ctrl+F"), self, lambda: self.search_input.setFocus())
        QShortcut(QKeySequence("Escape"), self, self.clear_current)

    def toggle_recording(self):
        if not self.is_recording:
            dev_index = self.device_combo.currentData()
            vad_level = self.vad_slider.value()
            self.audio_capture.device = dev_index
            self.audio_capture.vad = self.audio_capture.vad.__class__(vad_level)
            if self.audio_capture.start_recording():
                self.is_recording = True
                self.record_btn.setText("⏹️ Stop Recording")
                self.record_btn.setStyleSheet("background-color: #27ae60;")
                self.update_status("Recording...")
        else:
            self.audio_capture.stop_recording()
            self.is_recording = False
            self.record_btn.setText("🎤 Start Recording")
            self.record_btn.setStyleSheet("")
            self.update_status("Ready")

    def process_audio(self, audio_data):
        self.transcriber.transcribe(audio_data)

    def add_transcription(self, text):
        cursor = self.current_text.textCursor()
        cursor.movePosition(QTextCursor.End)
        cursor.insertText(text + " ")
        self.current_text.setTextCursor(cursor)
        self.database.save_transcript(text, session_id=self.session_id)
        if self.ai_mode:
            self.ai_companion.personality = self.personality_combo.currentText().lower()
            self.ai_companion.get_response(text)

    def add_ai_response(self, response):
        self.ai_response_text.clear()
        self.ai_response_text.setText(response)
        self.database.save_transcript(response, session_id=self.session_id, is_ai_response=True)
        cursor = self.current_text.textCursor()
        cursor.movePosition(QTextCursor.End)
        cursor.insertText(f"\n\n🤖 AI: {response}\n\n")
        self.current_text.setTextCursor(cursor)

    def toggle_ai_mode(self, checked):
        self.ai_mode = checked
        self.ai_response_widget.setVisible(checked)
        self.update_status("AI Companion Mode Active" if checked else "AI Companion Mode Disabled")

    def clear_current(self):
        self.current_text.clear()
        self.ai_response_text.clear()
        self.session_id = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.update_status("Cleared - New session started")

    def copy_to_clipboard(self):
        clipboard = QApplication.clipboard()
        clipboard.setText(self.current_text.toPlainText())
        self.update_status("Transcript copied to clipboard")

    def save_current(self):
        text = self.current_text.toPlainText()
        if not text.strip():
            self.update_status("Nothing to save")
            return
        filename = os.path.join(EXPORT_DIR, f"transcript_{self.session_id}.txt")
        with open(filename, "w", encoding="utf-8") as f:
            f.write(text)
        self.update_status(f"Saved to {filename}")

    def update_status(self, msg):
        self.status_label.setText(msg)
        self.status_bar.showMessage(msg, 5000)

    def load_recent_transcripts(self):
        self.history_list.clear()
        for row in self.database.get_recent(50):
            prefix = "🤖 AI: " if row[4] else "🗣️ You: "
            self.history_list.addItem(f'{prefix} [{row[1]}] {row[2]}')

    def search_transcripts(self):
        query = self.search_input.text()
        self.history_list.clear()
        results = self.database.search_transcripts(query)
        for row in results:
            prefix = "🤖 AI: " if row[4] else "🗣️ You: "
            self.history_list.addItem(f'{prefix} [{row[1]}] {row[2]}')

    def load_transcript_detail(self, item):
        self.current_text.setText(item.text())

    def export_transcripts(self, fmt):
        filename = os.path.join(EXPORT_DIR, f"export_{self.session_id}.{fmt}")
        if fmt == "txt":
            self.database.export_to_text(filename)
        elif fmt == "md":
            self.database.export_to_md(filename)
        elif fmt == "json":
            self.database.export_to_json(filename)
        self.update_status(f"Exported to {filename}")