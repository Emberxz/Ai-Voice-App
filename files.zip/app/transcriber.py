from PySide6.QtCore import QObject, Signal, QTimer
import os

class Transcriber(QObject):
    transcription_ready = Signal(str)
    error = Signal(str)

    def __init__(self, credentials_path=None):
        super().__init__()
        self.credentials_path = credentials_path or os.getenv("GOOGLE_APPLICATION_CREDENTIALS")
        self.use_mock = not self.credentials_path or not os.path.exists(self.credentials_path)

        if not self.use_mock:
            try:
                from google.cloud import speech
                self.speech_client = speech.SpeechClient()
            except Exception:
                self.use_mock = True

        self.mock_responses = [
            "Hello, this is a test transcription.",
            "The voice recognition system is working properly.",
            "You can integrate with Google Speech-to-Text API for real transcription.",
            "This is a demonstration of the VoiceScribe AI Companion.",
        ]
        self.response_index = 0

    def transcribe(self, audio_data):
        if self.use_mock:
            QTimer.singleShot(500, self.emit_mock)
        else:
            self._transcribe_google(audio_data)

    def emit_mock(self):
        response = self.mock_responses[self.response_index % len(self.mock_responses)]
        self.response_index += 1
        self.transcription_ready.emit(response)

    def _transcribe_google(self, audio_data):
        try:
            from google.cloud import speech
            audio = speech.RecognitionAudio(content=audio_data)
            config = speech.RecognitionConfig(
                encoding=speech.RecognitionConfig.AudioEncoding.LINEAR16,
                sample_rate_hertz=16000,
                language_code="en-US",
            )
            response = self.speech_client.recognize(config=config, audio=audio)
            if response.results:
                transcript = response.results[0].alternatives[0].transcript
                self.transcription_ready.emit(transcript)
            else:
                self.error.emit("No transcription result.")
        except Exception as e:
            self.error.emit(f"Transcription error: {e}")