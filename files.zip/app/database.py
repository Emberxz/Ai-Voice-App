import sqlite3
from pathlib import Path
import os

DATA_DIR = Path(os.path.dirname(__file__)).parent / "data"

class TranscriptDatabase:
    def __init__(self, db_path=DATA_DIR / "voicescribe.db"):
        self.db_path = str(db_path)
        self.init_database()

    def init_database(self):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS transcripts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                text TEXT NOT NULL,
                confidence REAL,
                session_id TEXT,
                is_ai_response BOOLEAN DEFAULT 0
            )
        ''')
        cursor.execute('''
            CREATE VIRTUAL TABLE IF NOT EXISTS transcripts_fts 
            USING fts5(text, content='transcripts', content_rowid='id')
        ''')
        cursor.execute('''
            CREATE TRIGGER IF NOT EXISTS transcripts_ai 
            AFTER INSERT ON transcripts BEGIN
                INSERT INTO transcripts_fts(rowid, text) 
                VALUES (new.id, new.text);
            END
        ''')
        conn.commit()
        conn.close()

    def save_transcript(self, text, confidence=None, session_id=None, is_ai_response=False):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO transcripts (text, confidence, session_id, is_ai_response)
            VALUES (?, ?, ?, ?)
        ''', (text, confidence, session_id, is_ai_response))
        transcript_id = cursor.lastrowid
        conn.commit()
        conn.close()
        return transcript_id

    def search_transcripts(self, query, limit=50):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        try:
            cursor.execute('''
                SELECT t.id, t.timestamp, t.text, t.confidence, t.is_ai_response
                FROM transcripts t
                JOIN transcripts_fts fts ON t.id = fts.rowid
                WHERE transcripts_fts MATCH ?
                ORDER BY t.timestamp DESC LIMIT ?
            ''', (query, limit))
            results = cursor.fetchall()
        except Exception:
            results = []
        conn.close()
        return results

    def get_recent(self, limit=100):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute('''
            SELECT id, timestamp, text, confidence, is_ai_response
            FROM transcripts ORDER BY timestamp DESC LIMIT ?
        ''', (limit,))
        results = cursor.fetchall()
        conn.close()
        return results

    def export_to_text(self, filename):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT timestamp, text, is_ai_response FROM transcripts ORDER BY timestamp")
        with open(filename, 'w', encoding='utf-8') as f:
            for row in cursor.fetchall():
                prefix = "AI: " if row[2] else "You: "
                f.write(f"[{row[0]}] {prefix}{row[1]}\n\n")
        conn.close()
        return filename

    def export_to_md(self, filename):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT timestamp, text, is_ai_response FROM transcripts ORDER BY timestamp")
        with open(filename, 'w', encoding='utf-8') as f:
            f.write("# Conversation History\n\n")
            for row in cursor.fetchall():
                prefix = "**AI:** " if row[2] else "**You:** "
                f.write(f"- `{row[0]}` {prefix}{row[1]}\n")
        conn.close()
        return filename

    def export_to_json(self, filename):
        import json
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT timestamp, text, is_ai_response FROM transcripts ORDER BY timestamp")
        data = [
            {"timestamp": row[0], "text": row[1], "is_ai_response": bool(row[2])}
            for row in cursor.fetchall()
        ]
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2)
        conn.close()
        return filename