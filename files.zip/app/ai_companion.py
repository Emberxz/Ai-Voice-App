from PySide6.QtCore import QObject, Signal, QTimer
import os
import json

class AICompanion(QObject):
    response_ready = Signal(str)
    error = Signal(str)

    def __init__(self, personality="friendly"):
        super().__init__()
        self.personality = personality
        self.use_mock = not os.getenv("OPENAI_API_KEY")
        self.personalities = self._load_personalities()

    def _load_personalities(self):
        config_path = os.path.join(os.path.dirname(__file__), "../config/personalities.json")
        if os.path.exists(config_path):
            with open(config_path, "r", encoding="utf-8") as f:
                return json.load(f)
        # Defaults
        return {
            "friendly": {"system_prompt": "You are a friendly AI assistant.", "temperature": 0.7},
            "professional": {"system_prompt": "You are a professional assistant.", "temperature": 0.3},
            "creative": {"system_prompt": "You are a creative companion.", "temperature": 0.9},
            "analytical": {"system_prompt": "You are an analytical assistant.", "temperature": 0.5},
        }

    def get_response(self, user_input):
        if self.use_mock:
            QTimer.singleShot(500, lambda: self.response_ready.emit("Mock AI response: " + user_input))
        else:
            self._get_response_openai(user_input)

    def _get_response_openai(self, user_input):
        try:
            import openai
            api_key = os.getenv("OPENAI_API_KEY")
            openai.api_key = api_key
            sys_prompt = self.personalities.get(self.personality.lower(), {}).get("system_prompt", "You are a helpful assistant.")
            temperature = self.personalities.get(self.personality.lower(), {}).get("temperature", 0.7)
            messages = [
                {"role": "system", "content": sys_prompt},
                {"role": "user", "content": user_input}
            ]
            response = openai.ChatCompletion.create(
                model=os.getenv("AI_MODEL", "gpt-3.5-turbo"),
                messages=messages,
                temperature=temperature,
                max_tokens=int(os.getenv("AI_MAX_TOKENS", "150"))
            )
            reply = response.choices[0].message.content
            self.response_ready.emit(reply)
        except Exception as e:
            self.error.emit(f"AI error: {e}")