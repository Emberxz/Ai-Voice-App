import sounddevice as sd
import numpy as np
import webrtcvad
from PySide6.QtCore import QObject, Signal

class AudioCapture(QObject):
    audio_chunk = Signal(bytes)
    status_update = Signal(str)

    def __init__(self, sample_rate=16000, blocksize=480, vad_aggressiveness=2, device=None):
        super().__init__()
        self.sample_rate = sample_rate
        self.blocksize = blocksize
        self.vad = webrtcvad.Vad(vad_aggressiveness)
        self.stream = None
        self.is_recording = False
        self.device = device

    def audio_callback(self, indata, frames, time, status):
        if self.is_recording:
            audio_int16 = (indata * 32767).astype(np.int16)
            audio_bytes = audio_int16.tobytes()
            try:
                is_speech = self.vad.is_speech(audio_bytes, self.sample_rate)
                if is_speech:
                    self.audio_chunk.emit(audio_bytes)
            except Exception:
                pass

    def start_recording(self):
        try:
            self.is_recording = True
            self.stream = sd.InputStream(
                samplerate=self.sample_rate,
                channels=1,
                dtype='float32',
                blocksize=self.blocksize,
                callback=self.audio_callback,
                device=self.device
            )
            self.stream.start()
            self.status_update.emit("Recording started...")
            return True
        except Exception as e:
            self.status_update.emit(f"Error: {str(e)}")
            return False

    def stop_recording(self):
        self.is_recording = False
        if self.stream:
            self.stream.stop()
            self.stream.close()
        self.status_update.emit("Recording stopped")